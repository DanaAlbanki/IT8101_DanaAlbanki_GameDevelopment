using UnityEngine;

public class Hole : MonoBehaviour
{
    public float moveSpeed = 3f;
    public float moveRange = 4f;

    Vector3 startPos;
    Vector3 targetPos;

    void Start()
    {
        startPos = transform.position;
        SetNewTarget();
    }

    void Update()
    {
        transform.position = Vector3.MoveTowards(transform.position, targetPos, moveSpeed * Time.deltaTime);

        if (Vector3.Distance(transform.position, targetPos) < 0.1f)
        {
            SetNewTarget();
        }
    }

    void SetNewTarget()
    {
        float randomX = Random.Range(-moveRange, moveRange);
        float randomZ = Random.Range(-moveRange, moveRange);

        targetPos = startPos + new Vector3(randomX, 0, randomZ);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            FindObjectOfType<ScoreManager>().GameOver();
        }
    }
}