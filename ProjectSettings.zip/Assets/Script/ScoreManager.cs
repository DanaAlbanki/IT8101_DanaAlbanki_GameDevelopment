using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class ScoreManager : MonoBehaviour
{
    int score = 0;

    public int goal = 8;

    float time = 0f;
    bool gameFinished = false;

    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI winText;

    public GameObject winPanel;

    void Start()
    {
        scoreText.text = "Score: 0";
        winPanel.SetActive(false);
    }

    void Update()
    {
        if (!gameFinished)
        {
            time += Time.deltaTime;
        }

        if (gameFinished && Input.GetKeyDown(KeyCode.R))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Collectible"))
        {
            other.gameObject.SetActive(false);
            score++;

            Debug.Log("Player collected a cube! Total Score: " + score);

            scoreText.text = "Score: " + score;

            if (score >= goal)
            {
                string currentScene = SceneManager.GetActiveScene().name;

                if (currentScene == "Level 1")
                {
                    SceneManager.LoadScene("Level 2");
                }
                else if (currentScene == "Level 2")
                {
                    SceneManager.LoadScene("Level 3");
                }
                else
                {
                    gameFinished = true;

                    winPanel.SetActive(true);

                    winText.text =
                        "YOU WIN!\n\n" +
                        "Time: " + time.ToString("F1") + " seconds\n" +
                        "Score: " + score + " / " + goal + "\n\n" +
                        "Press R to Restart";
                }
            }
        }
    }

    public void GameOver()
    {
        gameFinished = true;

        winPanel.SetActive(true);

        winText.text =
            "GAME OVER\n\n" +
            "You fell into the hole!\n\n" +
            "Press R to Restart";
    }
}